namespace Hkmp.Game.Client.Entity;

internal enum EntityType {
    FalseKnight = 1,
}
