﻿using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Guid("F34118B2-515D-4C33-88E6-9CFEF2AD5A15")]
[assembly: InternalsVisibleTo("HKMPServer")]
