namespace Hkmp;

/// <summary>
/// Static class that stores the version.
/// </summary>
internal static class Version {
    /// <summary>
    /// The version as a string.
    /// </summary>
    public const string String = "2.4.2";
}
