namespace Hkmp.Api.Eventing; 

/// <summary>
/// Abstract base class for server-side events.
/// </summary>
public abstract class ServerEvent {
}
